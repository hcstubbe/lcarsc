library(testthat)
library(lcarsM)

test_check("lcarsM")
