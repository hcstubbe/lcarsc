#' set_null_if_na 
#'
#' @description A fct function
#'
#' @return The return value, if any, from executing the function.
#'
#' @noRd

set_null_if_na = function(x) {
  if(is.null(x))
  {
    return(x)
  }
  if(is.na(x))
    {
    y = NULL
    }
  else
    {
    y = x
    }
  return(y)
}