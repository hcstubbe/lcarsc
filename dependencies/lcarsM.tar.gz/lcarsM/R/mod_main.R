#' main UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList
#' 
#' @importFrom shinyMobile f7Page f7TabLayout f7Panel f7Navbar f7Tabs f7Flex f7Tab f7Shadow f7Card f7Icon f7SmartSelect
#' 
#' @importFrom shinyWidgets prettyRadioButtons

mod_main_ui <- function(id){
  ns <- NS(id)
  tagList(
      f7TabLayout(
        panels = tagList(
          f7Panel(title = "Left Panel", side = "left", theme = "light", "Blabla", effect = "cover"),
          f7Panel(title = "Right Panel", side = "right", theme = "dark", "Blabla", effect = "cover")
        ),
        navbar = f7Navbar(
          title = "Tabs",
          hairline = TRUE,
          shadow = TRUE,
          leftPanel = TRUE,
          rightPanel = TRUE
        ),
        f7Tabs(
          animated = TRUE,
          #swipeable = TRUE,
          f7Tab(
            tabName = internal_data$labels_list$mod_main_tab1,
            icon = f7Icon("folder"),
            active = TRUE,
            
            f7Shadow(
              intensity = 10,
              hover = TRUE,
              f7Card(
                title = internal_data$labels_list$mod_main_tab1,
                "Wilkommen zur Studie!"
              )
            )
          ),
          f7Tab(
            tabName = internal_data$labels_list$mod_main_tab2,
            icon = f7Icon("keyboard"),
            active = FALSE,
            f7Shadow(
              intensity = 10,
              hover = TRUE,
              f7Card(
                title = internal_data$labels_list$mod_main_tab2,
                mod_input_form_ui(ns("input_form_1"))
              )
            )
          ),
          f7Tab(
            tabName = internal_data$labels_list$mod_main_tab3,
            icon = f7Icon("layers_alt"),
            active = FALSE,
            
            
            f7Shadow(
              intensity = 10,
              hover = TRUE,
              f7Card(
                title = internal_data$labels_list$mod_main_tab3,
                
                f7Flex(
                  prettyRadioButtons(
                    inputId = ns("theme"),
                    label = internal_data$labels_list$mod_main_select_theme,
                    thick = TRUE,
                    inline = TRUE,
                    selected = "md",
                    choices = internal_data$labels_list$mod_main_select_theme_choices,
                    animation = "pulse",
                    status = "info"
                  ),
                  
                  prettyRadioButtons(
                    inputId = ns("color"),
                    label = internal_data$labels_list$mod_main_select_color,
                    thick = TRUE,
                    inline = TRUE,
                    selected = "light",
                    choices = internal_data$labels_list$mod_main_select_color_choices,
                    animation = "pulse",
                    status = "info"
                  )
                ),
                
                tags$head(
                  tags$script(
                    'Shiny.addCustomMessageHandler("ui-tweak", function(message) {
                var os = message.os;
                var skin = message.skin;
                if (os === "md") {
                  $("html").addClass("md");
                  $("html").removeClass("ios");
                  $(".tab-link-highlight").show();
                } else if (os === "ios") {
                  $("html").addClass("ios");
                  $("html").removeClass("md");
                  $(".tab-link-highlight").hide();
                }

                if (skin === "dark") {
                 $("html").addClass("theme-dark");
                } else {
                  $("html").removeClass("theme-dark");
                }

               });
              '
                  )
                ),
                
              )
            )
          )
        )
      )
    )
  
}
    
#' main Server Functions
#'
#' @noRd 
mod_main_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
 
    
    # Run sub-module server
    mod_input_form_server("input_form_1")
    

    # send the theme to javascript
    observe({
      session$sendCustomMessage(
        type = "ui-tweak",
        message = list(os = input$theme, skin = input$color)
      )
    })
    
  })
}
    
## To be copied in the UI
# mod_main_ui("main_ui_1")
    
## To be copied in the server
# mod_main_server("main_ui_1")
