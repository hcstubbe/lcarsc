#' Run the Shiny Application
#'
#' @param ... arguments to pass to golem_opts. 
#' See `?golem::get_golem_options` for more details.
#' @inheritParams shiny::shinyApp
#'
#' @export
#' @importFrom shiny shinyApp
#' @importFrom golem with_golem_options 
run_app <- function(
  onStart = NULL,
  options = list(),
  enableBookmarking = NULL,
  uiPattern = "/",
  production_mode = NULL,
  ecrf_database_driver, # = RSQLite::SQLite(), # RMariaDB::MariaDB()
  ecrf_dbuser,
  ecrf_dbpassword,
  ecrf_dbhost,
  ecrf_dbname,
  config_database_driver, # RSQLite::SQLite(), # RMariaDB::MariaDB()
  config_dbuser,
  config_dbpassword,
  config_dbhost,
  config_dbname,
  ...
) {
  with_golem_options(
    app = shinyApp(
      ui = app_ui,
      server = app_server,
      onStart = onStart,
      options = options,
      enableBookmarking = enableBookmarking,
      uiPattern = uiPattern
    ),
    golem_opts = list(production_mode = production_mode,
                      pool = pool::dbPool(drv = ecrf_database_driver,
                                          user = ecrf_dbuser,
                                          password = ecrf_dbpassword,
                                          host = ecrf_dbhost,
                                          db = ecrf_dbname),
                      pool_config = pool::dbPool(drv = config_database_driver,
                                                 user = config_dbuser,
                                                 password = config_dbpassword,
                                                 host = config_dbhost,
                                                 db = config_dbname),
                      preview_mobile = preview_mobile
    )
  )
}