#' load_widget_data_mobile
#'
#' @description This function loads widget data for the mobile app.
#'
#' @return The loaded widget data.
#'
#' @noRd
#'
#' @import dplyr
#' @importFrom RMariaDB dbReadTable
#' @importFrom utils read.csv
#'
load_widget_data_mobile = function(pool_config){
  
  
  
  db_read_app_data = function(x_table, conn){
    
    if ( RMariaDB::dbExistsTable(conn = conn, name = x_table) ){
      x_table = RMariaDB::dbReadTable(conn = conn, name = x_table)
    } else {
      stop(paste0(x_table, " could not be found!"))
    }
    
    bool_cols = sapply(x_table, function(x){"TRUE" %in% x | "FALSE" %in% x & !any(x != "TRUE" & x != "FALSE" & !is.na(x))})
    x_table = x_table %>% dplyr::mutate(across(which(bool_cols), ~ as.logical(.x)))
    
    return(x_table)
  }
  
  all_visits = db_read_app_data(conn = pool_config, x_table = "visits")
  x = all_visits
  widget_data = list(all_visits = all_visits,
                     ordered_visits = all_visits %>% filter(!is.na(order)) %>% arrange(order),
                     widgets_table_global = db_read_app_data(conn = pool_config, x_table = "widgets"),
                     all_tabs = db_read_app_data(conn = pool_config, x_table = "panel_tabs"),
                     visit_choices = all_visits$visit_id[!(all_visits$inclusion_other_visit)])
  
  widget_data
}
