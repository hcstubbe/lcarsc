#' db_selector 
#'
#' @description This functions returns the pool object: in "production", the database connection is returned, which is specified in the run_app() call. In any other case a local database is generated.
#'
#' @return The pool object for the database connection.
#'
#' @importFrom pool dbPool
#'
#' @noRd
#' 
db_selector = function(production_mode, database_driver, dbuser, dbpassword, dbhost, dbname){
  if(production_mode == "production"){
    pool = pool::dbPool(drv = database_driver,
                        user = dbuser,
                        password = dbpassword,
                        host = dbhost,
                        db = dbname)
  }else{
    pool = pool::dbPool(
      drv = RSQLite::SQLite(),
      dbname = "db_mobile_preview.sqlite3",
      host = "dbeditortest",
      username = "testuser",
      password = "testuser")
  } 
  return(pool)
}