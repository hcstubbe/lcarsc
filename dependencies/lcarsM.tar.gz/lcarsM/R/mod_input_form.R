#' input_form UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList
#' @importFrom pool dbPool
#' @importFrom RMariaDB MariaDB
#' @importFrom DBI dbAppendTable dbListTables dbListTables dbCreateTable
#' @importFrom uuid UUIDgenerate
#' @importFrom golem get_golem_options
#' @importFrom shinyvalidate InputValidator sv_in_set sv_required
mod_input_form_ui <- function(id){
  ns <- NS(id)
  tagList(
    f7Flex(uiOutput(ns("input_form"))),
    f7Flex(uiOutput(ns("new_input_button")))
  )
}
    
#' input_form Server Functions
#'
#' @noRd 
mod_input_form_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    
    
    pool_config = golem::get_golem_options("pool_config")
    prod_mod = golem::get_golem_options("production_mode")
    
    prod_mod = get_production_mode(production_mode = prod_mod,
                                   pool_config = pool_config )
    
    # Load general server settings data
    server_settings_tbl = RMariaDB::dbReadTable(get_golem_options("pool_config"), "server_settings_tbl")
    visit_id = server_settings_tbl$visit_id_mobile
    tbl_id = paste('visit_table', visit_id, sep = '_')
    
    # Use local dummy database if in editor mode
    if(prod_mod == "production"){
      pool = get_golem_options("pool")
    }
    if(prod_mod == "editor"){
      pool = pool::dbPool(
        drv = RSQLite::SQLite(),
        dbname = "db_preview_mobile.sqlite3",
        host = "dbeditor",
        username = "user",
        password = "user"
      )
    }
    
    
    # Load widget data
    input_widget_data = load_widget_data_mobile(pool_config = golem::get_golem_options("pool_config"))
    input_widget_data = input_widget_data$widgets_table_global
    widget_data = input_widget_data[input_widget_data[,visit_id] == TRUE & input_widget_data$widget == TRUE,]
    
    

     
    # Render UI for input_form
    make_new_btn = function(){
      div(
        f7Flex(if(server_settings_tbl$enter_pid_manually == TRUE){
          f7Text(ns("pid_manual"), "Enter PID")
        }else{
          NULL
        }),
        br(), br(),
        f7Flex(f7Button(ns("new_input"), "Neu"))
      )
    }

    output$new_input_button = renderUI({
      make_new_btn()
    })
    
    server_settings_tbl = RMariaDB::dbReadTable(get_golem_options("pool_config"), "server_settings_tbl")
    rv_in = reactiveValues()
    if(server_settings_tbl$enter_pid_manually == TRUE){
      rv_in$pid = reactive({input$pid_manual})
    }
    
    
    # Add validator

    
    iv <- InputValidator$new()

    if(server_settings_tbl$enter_pid_manually == TRUE){
      valid_pids = RMariaDB::dbReadTable(conn = golem::get_golem_options("pool"), "inclusion_dataset")
      valid_pids = filter(valid_pids, deleted_row == FALSE & submitted_row == TRUE)
      valid_pids = valid_pids$pid
      iv$add_rule("pid_manual", sv_in_set(valid_pids))
      iv$enable()
    }
    
    
    ## Observe if new input button is clicked
    observeEvent(input$new_input, {
      
      if(iv$is_valid() | server_settings_tbl$enter_pid_manually == FALSE){
        
        if(server_settings_tbl$enter_pid_manually == FALSE){
          rv_in$pid = reactive({randomIdGenerator(exisiting_IDs = loadData(get_golem_options("pool"), tbl_id)$pid)})
        }
      
      output$input_form = renderUI({
        
        
          widget_list = makeWidgetList_simple(widget_data = widget_data,
                                              ns = ns,
                                              pid = rv_in$pid(),
                                              tbl_id = NULL,
                                              display_translation = server_settings_tbl$add_mobile_use_translation)
          tagList(
            f7Card(h3(paste0("Entry ID: ", rv_in$pid()))),
            widget_list,
            br(),
            br()
          )
        
      })
      
      
      output$new_input_button = renderUI({
        f7Flex(
          f7Card(f7Button(
            inputId = ns("save_btn"),
            label = "Speichern",
            href = NULL,
            color = "blue",
            fill = TRUE,
            outline = FALSE,
            shadow = TRUE,
            rounded = FALSE,
            size = NULL,
            active = FALSE
            )
          ),
         
          
          f7Card(
            f7Button(
              inputId = ns("abort_btn"),
              label = "Abbrechen",
              href = NULL,
              color = "red",
              fill = TRUE,
              outline = FALSE,
              shadow = TRUE,
              rounded = FALSE,
              size = NULL,
              active = FALSE
              )
            )
       )
        
      })
      
      }else if(!iv$is_valid() & server_settings_tbl$enter_pid_manually == TRUE){
        f7Dialog(
          id = ns("wrong_pid"),
          title = "PID nicht valide!",
          type = "confirm",
          text = "Bitte geben Sie eine valide PID ein!"
        )
    }
      
      })
    
    # Observe if save/abort button is clicked
    observeEvent(input$save_btn, {
      f7Dialog(
        id = ns("save_confirm"),
        title = "Daten speichern?",
        type = "confirm",
        text = "Bitte bestätigen Sie um die Daten zu speichern."
      )
    })
    
    ## Observe if confirm save button is clicked
    observeEvent(input$save_confirm, {
      if(input$save_confirm == TRUE){
        output$new_input_button = renderUI({
          make_new_btn()
        })
        output$input_form = NULL
        dbAppendTable(pool,tbl_id, formData())
        f7Toast(text = "Daten gesichert!")
      }
    })

    
    
    # Observe if abort button is clicked
    observeEvent(input$abort_btn, {
      f7Dialog(
        id = ns("abort_confirm"),
        title = "Forumlar zurücksetzen?",
        type = "confirm",
        text = "Wenn Sie bestätigen, werden die Eingaben gelöscht."
      )
    })
    
    
    
    ## Observe if confirm abort button is clicked
    observeEvent(input$abort_confirm, {
      if(input$abort_confirm == TRUE){
        output$new_input_button = renderUI({
          make_new_btn()
        })
        output$input_form = NULL
        f7Toast(text = "Forumlar zurückgesetzt!")
      }
    })
    
    
    ## Add widgets to database ----
    
    # Get required fields
    widgets_table = input_widget_data[input_widget_data[,visit_id] == TRUE | input_widget_data$widget_tab == "all",]
    fieldsAll = widgets_table$label
    names(fieldsAll) = widgets_table$inputId
    sql_tbl_vars = widgets_table$data_type
    names(sql_tbl_vars) = widgets_table$inputId
    
    # Check if database exists and create if required
    if(!is.element(tbl_id, dbListTables(pool))){
      dbCreateTable(pool, tbl_id, fields = sql_tbl_vars)
    }
    
    
    ## Gather input data ----
    formData <- reactive({
      input_data = sapply(names(fieldsAll), function(x) input[[x]], simplify = FALSE, USE.NAMES = TRUE)
      
      input_data = lapply(input_data, function(x){ # convert NULL to NA
        y = length(x)
        if(y == 0){
          NA
        }else{x}
      })
      
      input_data = data.frame(input_data)
      # Replace "New choice" with actual value from new choice text input
      choicesFromVar = !sapply(widgets_table$choicesFromVar, function(x) is.null(x) | x=="" | is.na(x))
      choicesFromVar = names(choicesFromVar) %in% colnames(input_data) & choicesFromVar
      if(any(choicesFromVar)){
        for(i in which(choicesFromVar)){
          if(input_data[,widgets_table$choicesFromVar[i]] != ""){
            input_data[,widgets_table$inputId[i]] = input_data[,widgets_table$choicesFromVar[i]] 
          }
        }
      }
      input_data$user_modified = Sys.getenv("SHINYPROXY_USERNAME")
      input_data$app_entry_id = rv_in$pid() 
      input_data$row_id = UUIDgenerate()
      input_data$visit_id = visit_id
      if(server_settings_tbl$enter_pid_manually == TRUE){
        input_data$pid = rv_in$pid() 
      }else{
        input_data$pid = Sys.getenv("SHINYPROXY_USERNAME")
      }
      input_data$date_modified = as.character(date())
      input_data$deleted_row = FALSE
      input_data$submitted_row = FALSE
      if(!is.null(input_data$inputId)){
        input_data$inputId = make.names(input_data$inputId)
      }
      if(!is.null(input_data$visit_id_visits)){
        input_data$visit_id_visits = make.names(input_data$visit_id_visits)
      }
      input_data
    })
    
  })
}
    
## To be copied in the UI
# mod_input_form_ui("input_form_1")
    
## To be copied in the server
# mod_input_form_server("input_form_1")
