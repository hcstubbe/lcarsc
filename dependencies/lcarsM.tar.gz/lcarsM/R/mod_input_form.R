#' input_form UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList
#' @importFrom pool dbPool
#' @importFrom RMariaDB MariaDB
#' @importFrom DBI dbAppendTable dbListTables dbListTables dbCreateTable
#' @importFrom uuid UUIDgenerate
#' @importFrom golem get_golem_options
mod_input_form_ui <- function(id){
  ns <- NS(id)
  tagList(
    f7Flex(uiOutput(ns("input_form"))),
    f7Flex(uiOutput(ns("new_input_button")))
  )
}
    
#' input_form Server Functions
#'
#' @noRd 
mod_input_form_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
    rv_in = reactiveValues()
    visit_id = "v0"
    tbl_id = "app_tbl"
    
    
    # Create database connection (local database if in preview mode)
    if(golem::get_golem_options("preview_mobile") == TRUE){
      pool = pool::dbPool(
        drv = RSQLite::SQLite(),
        dbname = "db_preview.sqlite3",
        host = "dbeditor",
        username = "user",
        password = "user"
      )
    }else{
      pool = get_golem_options("pool")
    }
    
    
    # Load widget data
    input_widget_data = load_widget_data_mobile(pool_config = golem::get_golem_options("pool_config"))
    input_widget_data = input_widget_data$widgets_table_global
    widget_data = subset(input_widget_data, (v_mobile == TRUE & widget == TRUE))
    
    

     
    # Render UI for input_form

    output$new_input_button = renderUI({
      f7Button(ns("new_input"), "Neu")
    })
    
    
    ## Observe if new input button is clicked
    observeEvent(input$new_input, {
      rv_in$pid = reactive({randomIdGenerator()})
      output$input_form = renderUI({
        
        widget_list = makeWidgetList_simple(widget_data = widget_data, ns = ns, pid = rv_in$pid(), tbl_id = NULL)
        tagList(
          f7Card(h3(rv_in$pid())),
          widget_list,
          br(),
          br()
        )
      })
      output$new_input_button = renderUI({
        
        f7Flex(
          f7Card(f7Button(
            inputId = ns("save_btn"),
            label = "Speichern",
            href = NULL,
            color = "blue",
            fill = TRUE,
            outline = FALSE,
            shadow = TRUE,
            rounded = FALSE,
            size = NULL,
            active = FALSE
            )
          ),
         
          
          f7Card(
            f7Button(
              inputId = ns("abort_btn"),
              label = "Abbrechen",
              href = NULL,
              color = "red",
              fill = TRUE,
              outline = FALSE,
              shadow = TRUE,
              rounded = FALSE,
              size = NULL,
              active = FALSE
              )
            )
       )
        
      })
      
    })
    
    # Observe if save/abort button is clicked
    observeEvent(input$save_btn, {
      f7Dialog(
        id = ns("save_confirm"),
        title = "Daten speichern?",
        type = "confirm",
        text = "Bitte bestätigen Sie um die Daten zu speichern."
      )
    })
    
    ## Observe if confirm save button is clicked
    observeEvent(input$save_confirm, {
      if(input$save_confirm == TRUE){
        output$new_input_button = renderUI({
          f7Button(ns("new_input"), "Neu")
        })
        output$input_form = NULL
        dbAppendTable(pool,tbl_id, formData())
        f7Toast(text = "Daten gesichert!")
      }
    })

    
    
    # Observe if abort button is clicked
    observeEvent(input$abort_btn, {
      f7Dialog(
        id = ns("abort_confirm"),
        title = "Forumlar zurücksetzen?",
        type = "confirm",
        text = "Wenn Sie bestätigen, werden die Eingaben gelöscht."
      )
    })
    
    
    
    ## Observe if confirm abort button is clicked
    observeEvent(input$abort_confirm, {
      if(input$abort_confirm == TRUE){
        output$new_input_button = renderUI({
          f7Button(ns("new_input"), "Neu")
        })
        output$input_form = NULL
        f7Toast(text = "Forumlar zurückgesetzt!")
      }
    })
    
    
    ## Add widgets to database ----
    
    # Get required fields
    widgets_table = subset(input_widget_data, (v_mobile == TRUE | widget_tab == "all"))
    fieldsAll = widgets_table$label
    names(fieldsAll) = widgets_table$inputId
    sql_tbl_vars = widgets_table$data_type
    names(sql_tbl_vars) = widgets_table$inputId
    
    # Check if database exists and create if required
    if(!is.element(tbl_id, dbListTables(pool))){
      dbCreateTable(pool, tbl_id, fields = sql_tbl_vars)
    }
    
    
    ## Gather input data ----
    formData <- reactive({
      input_data = sapply(names(fieldsAll), function(x) input[[x]], simplify = FALSE, USE.NAMES = TRUE)
      
      input_data = lapply(input_data, function(x){ # convert NULL to NA
        y = length(x)
        if(y == 0){
          NA
        }else{x}
      })
      
      input_data = data.frame(input_data)
      # Replace "New choice" with actual value from new choice text input
      choicesFromVar = !sapply(widgets_table$choicesFromVar, function(x) is.null(x) | x=="" | is.na(x))
      choicesFromVar = names(choicesFromVar) %in% colnames(input_data) & choicesFromVar
      if(any(choicesFromVar)){
        for(i in which(choicesFromVar)){
          if(input_data[,widgets_table$choicesFromVar[i]] != ""){
            input_data[,widgets_table$inputId[i]] = input_data[,widgets_table$choicesFromVar[i]] 
          }
        }
      }
      input_data$pid = rv_in$pid()
      input_data$row_id = UUIDgenerate()
      input_data$visit_id = visit_id
      input_data$user_modified = Sys.getenv("SHINYPROXY_USERNAME")
      input_data$date_modified = as.character(date())
      input_data$deleted_row = FALSE
      input_data$submitted_row = FALSE
      if(!is.null(input_data$inputId)){
        input_data$inputId = make.names(input_data$inputId)
      }
      if(!is.null(input_data$visit_id_visits)){
        input_data$visit_id_visits = make.names(input_data$visit_id_visits)
      }
      input_data
    })
    
  })
}
    
## To be copied in the UI
# mod_input_form_ui("input_form_1")
    
## To be copied in the server
# mod_input_form_server("input_form_1")
