# Launch the ShinyApp (Do not remove this comment)
# To deploy, run: rsconnect::deployApp()
# Or use the blue button on top of this file

pkgload::load_all(export_all = FALSE,helpers = FALSE,attach_testthat = FALSE)
options( "golem.app.prod" = TRUE)
# lcarsM::run_app(database_driver = RSQLite::SQLite(), dbuser = 'user', dbpassword = 'user', dbhost = 'dbpwa', dbname = 'mydbpwa.sqlite3', options = list(host = '0.0.0.0', port = 3838))
lcarsM::run_app(dbuser = 'user', dbpassword = 'user', dbhost = 'dbpwa', dbname = 'mydbpwa', production_mode = "production", options = list(host = '0.0.0.0', port = 3838))
